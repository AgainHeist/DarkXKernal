<?php
declare(strict_types=1);
// Hosting compatibility probe ONLY. Never authorizes a license.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('X-Again-Heist-Probe: 1');
http_response_code(200); // Legacy native client reads error messages only on HTTP 200.
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$fields = [];
foreach (['game', 'user_key', 'serial', 'version'] as $field) {
    $fields[$field] = isset($_POST[$field]) && is_string($_POST[$field]) && $_POST[$field] !== '';
}
$ok = $method === 'POST'
    && ($_POST['game'] ?? null) === 'FREEFIRE'
    && ($_POST['user_key'] ?? null) === 'ALi-HOSTING-PROBE'
    && ($_POST['serial'] ?? null) === 'hosting-test-device'
    && ($_POST['version'] ?? null) === '2.0';
echo json_encode([
    'status' => false,
    'message' => $ok ? 'AH_PROBE_OK_NOT_A_LICENSE' : 'AH_PROBE_READY_SEND_TEST_POST',
    'probe' => 'again-heist-php-v1',
    'diagnostics' => ['post_received' => $method === 'POST', 'fields_received' => $fields, 'test_payload_matched' => $ok],
], JSON_UNESCAPED_SLASHES);
