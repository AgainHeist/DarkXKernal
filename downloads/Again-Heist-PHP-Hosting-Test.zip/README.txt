AGAIN HEIST — INFINITYFREE / PHP COMPATIBILITY TEST (NOT FULL PANEL)

WHY FIRST?
The real native client POSTs form data to /connect. A website can work in a browser
while a free host's JavaScript/cookie challenge blocks curl and Android clients.
We must test that before porting the complete platform to PHP/MySQL.

UPLOAD
1. Prefer a NEW empty test subdomain/account. Do not overwrite an existing site.
2. Extract this ZIP. Upload index.php, connect.php and hidden .htaccess INSIDE
   that domain's htdocs folder, not above htdocs and not as an unextracted ZIP.
3. If the host already has .htaccess rules, back them up and merge the /connect
   rewrite rather than replacing unrelated rules. No chmod 777 is needed.
4. Enable/verify the domain's HTTPS certificate through the hosting panel.
5. Open https://YOUR-TEST-DOMAIN/ and run both browser checks.
6. Run the curl command displayed there on a separate computer or Termux.
   Use a fresh request WITHOUT copied browser cookies; do not follow a browser
   challenge to manufacture a misleading pass.

EXPECTED CURL RESPONSE
HTTP 200, application/json and:
{"status":false,"message":"AH_PROBE_OK_NOT_A_LICENSE",...}
The diagnostics.test_payload_matched must be true.

Use only these dummy form fields:
game=FREEFIRE
user_key=ALi-HOSTING-PROBE
serial=hosting-test-device
version=2.0

INTERPRETATION
- Browser AND fresh native request succeed at /connect: basic compatibility gate
  passed. Full PHP/MySQL implementation and actual-device UAT are still required.
- connect.php works but /connect fails: investigate Apache rewrite/.htaccess.
- Browser works but curl/Android returns HTML, aes.js, cookie/JavaScript challenge:
  this host/path is NOT proven suitable for the native API. Do not add a license
  bypass, disable device validation or assume the full panel will fix the host.
- HTTP 405 on a GET test is not native POST verification. Use the provided POST.

SAFETY / SCOPE
This probe always returns status:false, including on a successful TEST. There is
no authentication bypass, real key acceptance, database, owner account or payment
processing. It echoes only field-presence booleans, never submitted keys/serials.
It is intended to be public temporarily; remove it after the compatibility test.

The existing executable still calls:
https://originalcheats.myvipsite.fun/connect
A test subdomain does not redirect that executable. Do not modify/rebuild the
production client yet. If the real executable reaches this probe, it deliberately
reports failure with a probe message rather than ACTIVE.

NEXT
Send the public test URL and redacted response/screenshot. Do NOT send hosting
passwords, database credentials or API secrets. Full Again Heist PHP/MySQL work
should proceed only after this compatibility gate, with a separately planned
safe migration and approved native endpoint configuration.
